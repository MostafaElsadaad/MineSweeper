#ifndef _ROS_beginner_tutorials_motion_h
#define _ROS_beginner_tutorials_motion_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace beginner_tutorials
{

  class motion : public ros::Msg
  {
    public:
      typedef int16_t _FB_type;
      _FB_type FB;
      typedef int16_t _RL_type;
      _RL_type RL;
      typedef int16_t _FB2_type;
      _FB2_type FB2;
      typedef int16_t _RL2_type;
      _RL2_type RL2;
      typedef int16_t _RT_type;
      _RT_type RT;
      typedef int16_t _LT_type;
      _LT_type LT;
      typedef int8_t _A_type;
      _A_type A;
      typedef int8_t _B_type;
      _B_type B;
      typedef int8_t _X_type;
      _X_type X;
      typedef int8_t _Y_type;
      _Y_type Y;

    motion():
      FB(0),
      RL(0),
      FB2(0),
      RL2(0),
      RT(0),
      LT(0),
      A(0),
      B(0),
      X(0),
      Y(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        int16_t real;
        uint16_t base;
      } u_FB;
      u_FB.real = this->FB;
      *(outbuffer + offset + 0) = (u_FB.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_FB.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->FB);
      union {
        int16_t real;
        uint16_t base;
      } u_RL;
      u_RL.real = this->RL;
      *(outbuffer + offset + 0) = (u_RL.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_RL.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->RL);
      union {
        int16_t real;
        uint16_t base;
      } u_FB2;
      u_FB2.real = this->FB2;
      *(outbuffer + offset + 0) = (u_FB2.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_FB2.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->FB2);
      union {
        int16_t real;
        uint16_t base;
      } u_RL2;
      u_RL2.real = this->RL2;
      *(outbuffer + offset + 0) = (u_RL2.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_RL2.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->RL2);
      union {
        int16_t real;
        uint16_t base;
      } u_RT;
      u_RT.real = this->RT;
      *(outbuffer + offset + 0) = (u_RT.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_RT.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->RT);
      union {
        int16_t real;
        uint16_t base;
      } u_LT;
      u_LT.real = this->LT;
      *(outbuffer + offset + 0) = (u_LT.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_LT.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->LT);
      union {
        int8_t real;
        uint8_t base;
      } u_A;
      u_A.real = this->A;
      *(outbuffer + offset + 0) = (u_A.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->A);
      union {
        int8_t real;
        uint8_t base;
      } u_B;
      u_B.real = this->B;
      *(outbuffer + offset + 0) = (u_B.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->B);
      union {
        int8_t real;
        uint8_t base;
      } u_X;
      u_X.real = this->X;
      *(outbuffer + offset + 0) = (u_X.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->X);
      union {
        int8_t real;
        uint8_t base;
      } u_Y;
      u_Y.real = this->Y;
      *(outbuffer + offset + 0) = (u_Y.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->Y);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        int16_t real;
        uint16_t base;
      } u_FB;
      u_FB.base = 0;
      u_FB.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_FB.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->FB = u_FB.real;
      offset += sizeof(this->FB);
      union {
        int16_t real;
        uint16_t base;
      } u_RL;
      u_RL.base = 0;
      u_RL.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_RL.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->RL = u_RL.real;
      offset += sizeof(this->RL);
      union {
        int16_t real;
        uint16_t base;
      } u_FB2;
      u_FB2.base = 0;
      u_FB2.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_FB2.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->FB2 = u_FB2.real;
      offset += sizeof(this->FB2);
      union {
        int16_t real;
        uint16_t base;
      } u_RL2;
      u_RL2.base = 0;
      u_RL2.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_RL2.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->RL2 = u_RL2.real;
      offset += sizeof(this->RL2);
      union {
        int16_t real;
        uint16_t base;
      } u_RT;
      u_RT.base = 0;
      u_RT.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_RT.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->RT = u_RT.real;
      offset += sizeof(this->RT);
      union {
        int16_t real;
        uint16_t base;
      } u_LT;
      u_LT.base = 0;
      u_LT.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_LT.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->LT = u_LT.real;
      offset += sizeof(this->LT);
      union {
        int8_t real;
        uint8_t base;
      } u_A;
      u_A.base = 0;
      u_A.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->A = u_A.real;
      offset += sizeof(this->A);
      union {
        int8_t real;
        uint8_t base;
      } u_B;
      u_B.base = 0;
      u_B.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->B = u_B.real;
      offset += sizeof(this->B);
      union {
        int8_t real;
        uint8_t base;
      } u_X;
      u_X.base = 0;
      u_X.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->X = u_X.real;
      offset += sizeof(this->X);
      union {
        int8_t real;
        uint8_t base;
      } u_Y;
      u_Y.base = 0;
      u_Y.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->Y = u_Y.real;
      offset += sizeof(this->Y);
     return offset;
    }

    const char * getType(){ return "beginner_tutorials/motion"; };
    const char * getMD5(){ return "5a90697c887889015b0a01741efb0488"; };

  };

}
#endif
