#ifndef _ROS_using_markers_nav_h
#define _ROS_using_markers_nav_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace using_markers
{

  class nav : public ros::Msg
  {
    public:
      typedef int32_t _x_type;
      _x_type x;
      typedef int32_t _y_type;
      _y_type y;
      typedef int8_t _mine_type;
      _mine_type mine;
      typedef int16_t _mine_x_type;
      _mine_x_type mine_x;
      typedef int16_t _mine_y_type;
      _mine_y_type mine_y;
      typedef int16_t _mine_z_type;
      _mine_z_type mine_z;

    nav():
      x(0),
      y(0),
      mine(0),
      mine_x(0),
      mine_y(0),
      mine_z(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        int32_t real;
        uint32_t base;
      } u_x;
      u_x.real = this->x;
      *(outbuffer + offset + 0) = (u_x.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_x.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_x.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_x.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->x);
      union {
        int32_t real;
        uint32_t base;
      } u_y;
      u_y.real = this->y;
      *(outbuffer + offset + 0) = (u_y.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_y.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_y.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_y.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->y);
      union {
        int8_t real;
        uint8_t base;
      } u_mine;
      u_mine.real = this->mine;
      *(outbuffer + offset + 0) = (u_mine.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->mine);
      union {
        int16_t real;
        uint16_t base;
      } u_mine_x;
      u_mine_x.real = this->mine_x;
      *(outbuffer + offset + 0) = (u_mine_x.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_mine_x.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->mine_x);
      union {
        int16_t real;
        uint16_t base;
      } u_mine_y;
      u_mine_y.real = this->mine_y;
      *(outbuffer + offset + 0) = (u_mine_y.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_mine_y.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->mine_y);
      union {
        int16_t real;
        uint16_t base;
      } u_mine_z;
      u_mine_z.real = this->mine_z;
      *(outbuffer + offset + 0) = (u_mine_z.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_mine_z.base >> (8 * 1)) & 0xFF;
      offset += sizeof(this->mine_z);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        int32_t real;
        uint32_t base;
      } u_x;
      u_x.base = 0;
      u_x.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_x.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_x.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_x.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->x = u_x.real;
      offset += sizeof(this->x);
      union {
        int32_t real;
        uint32_t base;
      } u_y;
      u_y.base = 0;
      u_y.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_y.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_y.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_y.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->y = u_y.real;
      offset += sizeof(this->y);
      union {
        int8_t real;
        uint8_t base;
      } u_mine;
      u_mine.base = 0;
      u_mine.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->mine = u_mine.real;
      offset += sizeof(this->mine);
      union {
        int16_t real;
        uint16_t base;
      } u_mine_x;
      u_mine_x.base = 0;
      u_mine_x.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_mine_x.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->mine_x = u_mine_x.real;
      offset += sizeof(this->mine_x);
      union {
        int16_t real;
        uint16_t base;
      } u_mine_y;
      u_mine_y.base = 0;
      u_mine_y.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_mine_y.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->mine_y = u_mine_y.real;
      offset += sizeof(this->mine_y);
      union {
        int16_t real;
        uint16_t base;
      } u_mine_z;
      u_mine_z.base = 0;
      u_mine_z.base |= ((uint16_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_mine_z.base |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->mine_z = u_mine_z.real;
      offset += sizeof(this->mine_z);
     return offset;
    }

    const char * getType(){ return "using_markers/nav"; };
    const char * getMD5(){ return "3765e4cc54ad6081e2daedf793fdbb9a"; };

  };

}
#endif
